## setup

```
pip install -r requirements.txt
```

## Result

origin:

![](origin.png)

reconstruct:

![](reconstruct.png)